import os
from io import StringIO
from typing.io import TextIO

from ruamel.yaml import YAML
from typing import Any, Union


class YamlUtil:
    # 类级缓存YAML实例
    _yaml_parser: Union[YAML, None] = None

    @classmethod
    def _get_yaml_parser(cls) -> YAML:
        """初始化并缓存YAML解析器（线程安全）"""
        if cls._yaml_parser is None:
            yaml = YAML(typ='rt')
            yaml.preserve_quotes = True
            yaml.default_flow_style = False
            cls._yaml_parser = yaml
        return cls._yaml_parser

    @classmethod
    def dump_yaml(cls, data: Any) -> str:
        """将Python对象序列化为YAML字符串

        Args:
            data: 要序列化的Python对象

        Returns:
            YAML格式字符串
        """
        yaml = cls._get_yaml_parser()
        with StringIO() as buffer:
            yaml.dump(data, buffer)
            return buffer.getvalue()

    @classmethod
    def load_yaml(cls, stream: Union[str, StringIO, TextIO]) -> Any:
        """从YAML流加载Python对象

        Args:
            stream: YAML字符串或StringIO对象

        Returns:
            解析后的Python对象
        """
        yaml = cls._get_yaml_parser()
        return yaml.load(stream)

    @classmethod
    def load_yaml_file(cls, file_path):
        """从YAML文件加载Python对象"""
        with open(file_path, 'r', encoding='utf-8') as file:
            return YamlUtil.load_yaml(file)

    @staticmethod
    def has_yaml_files(cases_path):
        """检查目录下是否存在.yaml或.yml文件"""
        # 判断目录是否存在
        if not os.path.isdir(cases_path):
            return False

        # 遍历目录内容
        for entry in os.listdir(cases_path):
            # 拼接完整路径
            full_path = os.path.join(cases_path, entry)

            # 检查是否是文件且后缀符合要求（不区分大小写）
            if os.path.isfile(full_path) and entry.lower().endswith(('.yaml', '.yml')):
                return True

        return False
