import os
import threading
from concurrent.futures import as_completed
from pathlib import Path

from computenestcli.base_log import get_user_logger
from computenestcli.common.constant import CREATED, UPDATED, TOTAL, SKIPPED, FAILED
from computenestcli.common.logging_constant import BUILD_SERVICE

user_logger = get_user_logger(BUILD_SERVICE)


class ServiceTestHelper:
    def __init__(self, operation_type):
        self._lock = threading.RLock()  # 可重入锁
        self.result = {
            TOTAL: 0,
            CREATED: 0,
            UPDATED: 0,
            SKIPPED: 0,
            FAILED: []
        }
        self.operation_type = operation_type

    def record_success(self, status):
        if status in [CREATED, UPDATED, SKIPPED]:
            with self._lock:
                self.result[TOTAL] += 1
                self.result[status] += 1

    def record_error(self, filename, error):
        with self._lock:
            self.result[FAILED].append(f"{filename}: {error}")

    def log_summary(self):
        """Formatted result summary logging"""
        if self.result[TOTAL] == 0:
            return
        summary_lines = [
            f"📊 Test Cases {self.operation_type} Summary:",
            f"  Total: {self.result[TOTAL]} cases",
            f"  ✅ Created: {self.result[CREATED]}",
            f"  🔄 Updated: {self.result[UPDATED]}",
            f"  ⏩ Skipped: {self.result[SKIPPED]}",
            f"  ❌ FAILED: {len(self.result[FAILED])}",
        ]
        for line in summary_lines:
            user_logger.info(line)
        if self.result[FAILED]:
            user_logger.error("Failed Cases:\n" + "\n".join(self.result[FAILED]))

    def process_futures(self, future_items):
        """通用并发任务结果处理方法"""
        for future in as_completed(future_items):
            item_name = future_items[future]
            status, msg = future.result()
            if status == FAILED:
                self.record_error(item_name, msg)
            else:
                self.record_success(status)
        self.log_summary()

    @staticmethod
    def build_case_file_path(template_name: str, cases_path) -> str:
        """统一构建用例文件路径"""
        return os.path.join(cases_path, f"{template_name}.yaml")

    @staticmethod
    def validate_case_file(case_data, file_path):
        """校验服务测试用例文件"""
        try:
            if not case_data.get('templateName'):
                user_logger.warning(f"Missing required field 'templateName' in {file_path}")
                return False
            if not isinstance(case_data.get('parameters'), dict):
                user_logger.warning(f"Missing parameters in {file_path}")
                return False
            return True
        except Exception as e:
            user_logger.warning(f"YAML parsing failed in {file_path}: {str(e)}")
            return False

    @staticmethod
    def get_case_files(cases_path, region_id=None):
        """
        获取所有测试用例文件路径，可根据region_id筛选

        Args:
            cases_path: 测试用例目录路径
            region_id: 区域ID，如果提供，将只返回符合该区域的测试用例文件

        Returns:
            符合条件的测试用例文件路径列表
        """
        if not os.path.isdir(cases_path):
            return []

        # 获取所有YAML文件
        all_yaml_files = [
            os.path.join(cases_path, f)
            for f in os.listdir(cases_path)
            if f.lower().endswith(('.yaml', '.yml'))
        ]

        # 如果没有指定region_id，返回所有文件
        if region_id is None:
            return all_yaml_files

        # 根据region_id筛选文件
        is_international = region_id == "ap-southeast-1"
        filtered_files = []

        for file_path in all_yaml_files:
            file_name = Path(file_path).stem

            # 如果是国际化区域，只返回带international后缀的文件
            # 如果是国内区域，只返回不带international后缀的文件
            if (is_international and file_name.endswith("-international")) or \
                    (not is_international and not file_name.endswith("-international")):
                filtered_files.append(file_path)

        return filtered_files

