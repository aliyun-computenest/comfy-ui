
class Credentials:
    def __init__(self, access_key_id, access_key_secret, security_token=""):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.security_token = security_token
