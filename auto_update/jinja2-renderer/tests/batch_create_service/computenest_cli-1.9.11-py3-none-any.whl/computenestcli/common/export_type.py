from enum import Enum


class ExportType(Enum):
    CONFIG_ONLY = "ConfigOnly"
    FULL_SERVICE = "FullService"
