from enum import Enum


class Locale(Enum):
    ZH_CN = "zh-CN"
    EN_US = "en-US"
