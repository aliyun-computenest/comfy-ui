import json
import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import List

from computenestcli.base_log import get_user_logger, log_monitor
from computenestcli.common import constant
from computenestcli.common.constant import FAILED, CREATED, UPDATED, SERVICE_TEST_CASE_ID, \
    SERVICE_TEST_PARAMETERS, TEMPLATE_NAME, SKIPPED, GENERATE_OPERATION, IMPORT_OPERATION, EXECUTE_OPERATION, FAILED, \
    EXPORT_OPERATION, CN_HANGZHOU, AP_SOUTHEAST_1
from computenestcli.common.file_util import FileUtil
from computenestcli.common.logging_constant import SERVICE_TEST
from computenestcli.common.service_processor_helper import ServiceProcessorHelper
from computenestcli.common.service_test_helper import ServiceTestHelper
from computenestcli.common.yaml_util import YamlUtil
from computenestcli.exception.cli_common_exception import CliCommonException
from computenestcli.service.supplier import SupplierService

user_logger = get_user_logger(SERVICE_TEST)

# 添加常量定义
REGION_ID = "regionId"
DEFAULT_REGION_ID = CN_HANGZHOU
INTERNATIONAL_REGION_ID = AP_SOUTHEAST_1
INTERNATIONAL_SUFFIX = "-international"


class ServiceTestProcessor:
    def __init__(self, context):
        self.context = context
        self._executor = ThreadPoolExecutor(max_workers=4)

    @log_monitor("BuildService", "ServiceTest", "GenerateDefaultCases")
    def generate_default_cases(self, service_id, service_name, version_name, cases_path, overwrite=True,
                               region_id=DEFAULT_REGION_ID):
        # 获取服务id
        if not service_id and service_name:
            service_id = SupplierService.query_service_id_by_name(self.context, service_name)
        if not service_id:
            raise CliCommonException("Service id or service name is required")
        """核心生成逻辑"""
        if YamlUtil.has_yaml_files(cases_path) and not overwrite:
            user_logger.warning("The service test directory is not empty, please use --overwrite.")
            return

        # 1. 获取服务模板信息
        service_response = SupplierService.get_service(self.context, service_id, version_name)
        service_deploy_metadata = json.loads(service_response.body.deploy_metadata)
        service_template_list = service_deploy_metadata.get(constant.TEMPLATE_CONFIGS, [])
        if not version_name:
            version_name = service_response.body.version
        # 2. 创建输出目录
        os.makedirs(cases_path, exist_ok=True)

        # 3. 生成默认用例
        generated_cases = []

        # 执行并行任务
        result_recorder = ServiceTestHelper(GENERATE_OPERATION)
        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="service_test") as executor:
            future_file_name = {}
            for template_config in service_template_list:
                template_name = template_config.get('Name')
                if not template_name:
                    continue
                future = executor.submit(self._generate_single_case, service_id, version_name,
                                         template_name, generated_cases, overwrite, cases_path, region_id)
                future_file_name[future] = template_name
            result_recorder.process_futures(future_file_name)

    def _generate_single_case(self, service_id, version_name, template_name, generated_cases, overwrite, cases_path,
                              region_id=DEFAULT_REGION_ID):
        # 生成用例配置
        response = SupplierService.generate_default_service_test_config(
            self.context,
            service_id,
            version_name,
            template_name
        )
        if not response.body or not response.body.test_config:
            raise CliCommonException("Empty test config response")
        test_config_yaml = YamlUtil.load_yaml(response.body.test_config)
        # 构建完整用例数据 - 使用传入的region_id
        case_data = {
            TEMPLATE_NAME: template_name,
            REGION_ID: region_id,
            SERVICE_TEST_PARAMETERS: test_config_yaml.get(SERVICE_TEST_PARAMETERS, {}),
        }

        # 只有当region_id为ap-southeast-1时才添加-international后缀
        is_international = region_id == INTERNATIONAL_REGION_ID
        file_name = f"{template_name}{INTERNATIONAL_SUFFIX if is_international else ''}"
        file_path = ServiceTestHelper.build_case_file_path(file_name, cases_path)

        if not os.path.exists(file_path):
            case_data_saved = YamlUtil.dump_yaml(case_data)
            FileUtil.write_to_file(file_path, case_data_saved)
            generated_cases.append(file_path)
            user_logger.info(f"📦 Generated default test cases for {file_name}")
            return CREATED, file_name
        elif overwrite:
            current_case_data = YamlUtil.load_yaml_file(file_path)
            current_case_id = current_case_data.get(SERVICE_TEST_CASE_ID)
            if current_case_id:
                case_data[SERVICE_TEST_CASE_ID] = current_case_id
            case_data_saved = YamlUtil.dump_yaml(case_data)
            FileUtil.write_to_file(file_path, case_data_saved)
            generated_cases.append(file_path)
            user_logger.info(f"📦 update default test cases for {file_name}")
            return UPDATED, file_name
        else:
            return SKIPPED, file_name

    @log_monitor("BuildService", "ServiceTest", "ImportTestCases")
    def import_service_test_cases(self, service_id, service_name, version_name, cases_path,
                                  region_id=DEFAULT_REGION_ID):
        if not service_id and service_name:
            service_id = SupplierService.query_service_id_by_name(self.context, service_name)
        if not version_name:
            service_response = SupplierService.get_service(self.context, service_id, version_name)
            version_name = service_response.body.version
        """核心导入逻辑"""
        # 检查目录是否存在，如果不存在则创建
        if not os.path.exists(cases_path):
            os.makedirs(cases_path, exist_ok=True)
        # 获取符合当前region_id的测试用例文件
        case_files = ServiceTestHelper.get_case_files(cases_path, region_id)

        # 如果没有符合当前region_id的测试用例文件，则生成默认用例
        if not case_files:
            self.generate_default_cases(
                service_id=service_id,
                service_name="",
                version_name=version_name,
                cases_path=cases_path,
                overwrite=True,
                region_id=region_id
            )
            # 重新获取生成后的文件列表
            case_files = ServiceTestHelper.get_case_files(cases_path, region_id)

        # 继续处理导入逻辑...
        result_recorder = ServiceTestHelper(IMPORT_OPERATION)
        with ThreadPoolExecutor(max_workers=4, thread_name_prefix="service_test") as executor:
            future_file_name = {}
            for path in case_files:
                future = executor.submit(self._import_service_test_case, service_id, version_name, path, region_id)
                future_file_name[future] = os.path.basename(path)

            result_recorder.process_futures(future_file_name)

    def _import_service_test_case(self, service_id, service_version, file_path, region_id=DEFAULT_REGION_ID):
        """单个测试用例导入核心逻辑"""
        # 读取用例文件
        with open(file_path, 'r', encoding='utf-8') as file:
            # 结构校验
            case_name = Path(file_path).stem
            case_data = YamlUtil.load_yaml(file) or {}
            if not ServiceTestHelper.validate_case_file(case_data, file_path):
                return FAILED
            # 提取核心配置
            test_config = {
                SERVICE_TEST_PARAMETERS: case_data.get(SERVICE_TEST_PARAMETERS, {}),
            }
            test_config_yaml = YamlUtil.dump_yaml(test_config)

            # 判断操作类型
            case_id = case_data.get(SERVICE_TEST_CASE_ID)
            try:
                if not case_id:
                    # 创建新用例
                    response = SupplierService.create_service_test_case(
                        context=self.context,
                        service_id=service_id,
                        service_test_config=test_config_yaml,
                        service_version=service_version,
                        test_case_name=case_data[TEMPLATE_NAME],
                        template_name=case_data[TEMPLATE_NAME]
                    )
                    if not response.body or not response.body.test_case_id:
                        raise CliCommonException("Empty test case id response")
                    case_data[SERVICE_TEST_CASE_ID] = response.body.test_case_id
                    test_config_yaml = YamlUtil.dump_yaml(case_data)
                    FileUtil.write_to_file(file_path, test_config_yaml)
                    return CREATED, None
                else:
                    # 更新已有用例
                    SupplierService.update_service_test_case(
                        context=self.context,
                        case_id=case_id,
                        service_test_config=test_config_yaml,
                        test_case_name=case_name
                    )
                    return UPDATED, None
            except Exception as e:
                msg = f"❌ Failed to import service test case: {str(e)}"
                return FAILED, msg

    def execute_cases(self, task_name, cases_path, task_region_id=None, file_path=None, region_id=DEFAULT_REGION_ID):
        if not task_region_id:
            try:
                config_data = YamlUtil.load_yaml_file(file_path)
                # 从Artifact中查找任何包含RegionId的EcsImage子节点
                artifact_region_id = None
                artifact_section = config_data.get('Artifact', {})
                for key, value in artifact_section.items():
                    if isinstance(value, dict) and 'RegionId' in value:
                        artifact_region_id = value.get('RegionId')
                        break

                    # 检查SupportRegionIds（如果存在且非空）
                    support_region_ids = value.get('SupportRegionIds')
                    if isinstance(support_region_ids, list) and support_region_ids:
                        artifact_region_id = support_region_ids[0]
                        break

                # 从ImageBuilder中查找任何包含RegionId的子节点
                image_builder_region_id = None
                image_builder_section = config_data.get('ImageBuilder', {})
                for key, value in image_builder_section.items():
                    if isinstance(value, dict) and 'RegionId' in value:
                        image_builder_region_id = value.get('RegionId')
                        break

                # 优先使用ImageBuilder其次，其次使用Artifact中的RegionId中的
                if image_builder_region_id:
                    task_region_id = image_builder_region_id
                elif artifact_region_id:
                    task_region_id = artifact_region_id
                else:
                    raise CliCommonException("No region ID found in configuration.")

                user_logger.info(f"Target region is {task_region_id}.")
            except Exception as e:
                raise CliCommonException(f"Failed to determine target region: {str(e)}")

        case_files = ServiceTestHelper.get_case_files(cases_path, region_id)
        if not case_files:
            user_logger.warning("No test cases found in the specified directory.")
            return

        case_ids = []
        result_recorder = ServiceTestHelper(EXECUTE_OPERATION)

        for case_file in case_files:
            with open(case_file, 'r', encoding='utf-8') as f:
                case_data = YamlUtil.load_yaml(f)

            # 提取必要参数
            case_id = case_data.get(SERVICE_TEST_CASE_ID)
            case_name = Path(case_file).stem

            # 检查文件中的regionId - 如果没有设置，默认为cn-hangzhou
            case_region_id = case_data.get(REGION_ID, DEFAULT_REGION_ID)

            # 检查region是否匹配
            if case_region_id != region_id:
                user_logger.warning(
                    f"Skipping case {case_name}: Region mismatch (file: {case_region_id}, target: {task_region_id})")
                continue

            if not case_id:
                msg = f"Missing required parameter: caseId"
                result_recorder.record_error(case_name, msg)
                continue

            result_recorder.record_success(CREATED)
            case_ids.append(case_id)

        result_recorder.log_summary()
        if not case_ids:
            user_logger.warning("No valid test cases found in the specified directory.")
            return
        result = SupplierService.create_service_test_task(context=self.context, test_case_ids=case_ids,
                                                          task_name=task_name, task_region_id=task_region_id)
        if result.body.task_id:
            user_logger.info(f"✅ Create service test task success, taskId: {result.body.task_id}, "
                             f"Please proceed to the Compute Nest console（computenest.console.aliyun.com）"
                             f"to check the execution status of the task.")
            return result.body.task_id
        else:
            user_logger.warning(f"❌ Create service test task failed")

    @log_monitor("BuildService", "ExportTestCases")
    def export_service_test_cases(self, service_id, service_name, version_name, cases_path, region_id=DEFAULT_REGION_ID):
        if not service_id and not service_name:
            raise CliCommonException("Please specify service id or service name")
        if not service_id and service_name:
            service_id = SupplierService.query_service_id_by_name(self.context, service_name)
        """当创建新版的服务时，需要将同步云端测试用例到本地目录（保留原有注释）
           或手动执行导出服务测试case文件
        """
        try:
            if not version_name:
                service_response = SupplierService.get_service(self.context, service_id, version_name)
                version_name = service_response.body.version
            result_recorder = ServiceTestHelper(EXPORT_OPERATION)
            all_cases = self._list_all_remote_cases(service_id, version_name)
            if not all_cases:
                return
            case_files = ServiceTestHelper.get_case_files(cases_path, region_id)
            local_case_filename_array = [Path(file_path).stem for file_path in case_files]
            with ThreadPoolExecutor(max_workers=4, thread_name_prefix="export_cases") as executor:
                future_case_name = {}
                for case in all_cases:
                    case_name = case.test_case_name
                    future = executor.submit(self._export_sing_service_test_case, local_case_filename_array,
                                             case, cases_path, region_id)
                    future_case_name[future] = case_name
                result_recorder.process_futures(future_case_name)
        except Exception as e:
            user_logger.warning(f"export service test cases failed: {e.__cause__}"
                                f"Please manually export the service test case file to the latest status.")

    def _export_sing_service_test_case(self, case_filename_array, case, cases_path, region_id=DEFAULT_REGION_ID):
        template_name = case.template_name
        case_name = case.test_case_name
        test_config = YamlUtil.load_yaml(case.test_config) or {}
        if not template_name or not case_name:
            return FAILED, None

        try:
            # 只有当region_id为ap-southeast-1时才添加-international后缀
            is_international = region_id == INTERNATIONAL_REGION_ID
            file_name = f"{case_name}{INTERNATIONAL_SUFFIX if is_international else ''}"

            # 同步云端到本地时采用原本的case_name
            file_path = ServiceTestHelper.build_case_file_path(file_name, cases_path)
            # 合并数据
            remote_data = {
                SERVICE_TEST_CASE_ID: case.test_case_id,
                TEMPLATE_NAME: template_name,
                REGION_ID: region_id,
                SERVICE_TEST_PARAMETERS: test_config.get(SERVICE_TEST_PARAMETERS)
            }
            test_config_yaml = YamlUtil.dump_yaml(remote_data)
            FileUtil.write_to_file(file_path, test_config_yaml)
            # 记录结果
            if file_name in case_filename_array:
                return UPDATED, None
            else:
                return CREATED, None
        except Exception as e:
            error_msg = f"{case_name}: {str(e)}"
            return FAILED, error_msg

    def _list_all_remote_cases(self, service_id, version) -> List:
        """分页获取云端用例"""
        all_cases = []
        next_token = None

        while True:
            response = SupplierService.list_service_test_cases(
                self.context, service_id, version,
                next_token=next_token
            )

            if not response.body or not response.body.data:
                break

            all_cases.extend(response.body.data)
            next_token = response.body.next_token
            if not next_token:
                break

        return all_cases
