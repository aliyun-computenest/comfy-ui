import yaml
import os
from computenestcli.common import constant
from computenestcli.base_log import get_user_logger, log_monitor
from computenestcli.common.logging_constant import BUILD_SERVICE
from computenestcli.common.terraform_util import TerraformUtil
from computenestcli.processor.ros_function.ros_function_handler import ArtifactRegistry

user_logger = get_user_logger(BUILD_SERVICE)


class CheckProcessor:
    def __init__(self, config, file_path, service_name, service_id):
        self.config = config
        self.file_path = file_path
        self.service_name = service_name
        self.service_id = service_id
        self.checks = [self.validate_allowed_regions, self.validate_image_key]
        self.errors = []
        self.artifact_registry = ArtifactRegistry()

    def validate_allowed_regions(self):
        support_regions = []
        if constant.ARTIFACT not in self.config:
            return True
        deploy_metadata = self.config[constant.SERVICE][constant.DEPLOY_METADATA]
        if self.config[constant.SERVICE][constant.SERVICE_TYPE] == constant.MANAGED:
            template_configs = deploy_metadata[constant.SUPPLIER_DEPLOY_METADATA][constant.SUPPLIER_TEMPLATE_CONFIGS]
        else:
            template_configs = deploy_metadata[constant.TEMPLATE_CONFIGS]

        for artifact in self.config[constant.ARTIFACT]:
            if self.config[constant.ARTIFACT][artifact][constant.ARTIFACT_TYPE] == constant.ECS_IMAGE:
                support_region_ids = self.config[constant.ARTIFACT][artifact].get(constant.SUPPORT_REGION_IDS, "")

                if support_region_ids:
                    support_regions.extend(support_region_ids)
                    for config in template_configs:
                        allowed_regions = config[constant.ALLOWED_REGIONS]
                        if set(allowed_regions).issubset(set(support_regions)):
                            continue
                        else:
                            self.errors.append(
                                "The AllowedRegions in TemplateConfigs are beyond the scope of SupportRegionIds in Artifact.")
                            return False
        return True

    def validate_image_key(self):
        if not constant.DEPLOY_METADATA in self.config[constant.SERVICE]:
            return True

        deploy_metadata = self.config[constant.SERVICE][constant.DEPLOY_METADATA]

        if self.config[constant.SERVICE][constant.SERVICE_TYPE] == constant.MANAGED:
            template_configs = deploy_metadata[constant.SUPPLIER_DEPLOY_METADATA][constant.SUPPLIER_TEMPLATE_CONFIGS]
        else:
            template_configs = deploy_metadata[constant.TEMPLATE_CONFIGS]

        # 如果是Terraform 部署方式，跳过此检查
        if not self.config[constant.SERVICE].get(constant.DEPLOY_TYPE):
            terraform_path = TerraformUtil.exist_terraform_structure(os.path.dirname(self.file_path))
            if isinstance(terraform_path, str):
                return True

        template_image_ids = set()
        config_image_ids = set()
        for template in template_configs:
            # 将相对路径替换成绝对路径
            template_path = os.path.join(os.path.dirname(self.file_path), template.get(constant.URL))
            template = self.read_yaml_file(template_path)
            template_image_ids.update(self.get_image_ids(template))
            supplier_deploy_metadata = deploy_metadata.get(constant.SUPPLIER_DEPLOY_METADATA, None)
            if supplier_deploy_metadata is None:
                return True
            if constant.ARTIFACT_RELATION not in supplier_deploy_metadata:
                return True
            config_image_ids.update(self.config[constant.SERVICE][constant.DEPLOY_METADATA][
                                        constant.SUPPLIER_DEPLOY_METADATA][constant.ARTIFACT_RELATION].keys())
        if not config_image_ids.issubset(template_image_ids):
            self.errors.append(f"The ImageId in template.yaml does not match the image identifier in config.yaml."
                               f" The config image ids are: {config_image_ids}, the template image ids are: {template_image_ids}")
            return False

        return True

    @staticmethod
    def read_yaml_file(file):
        with open(file, 'r') as f:
            return yaml.safe_load(f)

    def get_image_ids(self, template):
        """获取模板中的所有镜像ID"""
        image_ids = set()
        context = self._build_context(template)
        self._search_image_ids(template, image_ids, context)
        return image_ids

    def _build_context(self, template):
        """构建部署物解析上下文"""
        context = {}
        if isinstance(template, dict):
            # 提取映射表，用于 Fn::FindInMap 解析
            if 'Mappings' in template:
                context['mappings'] = template['Mappings']
            # 提取参数定义，用于参数引用解析
            if 'Parameters' in template:
                context['parameters'] = template['Parameters']
        return context

    def _search_image_ids(self, obj, image_ids, context):
        """
        递归搜索数据结构中的镜像ID

        Args:
            obj: 要搜索的数据对象
            image_ids: 存储镜像ID的集合
            context: 解析上下文（包含Mappings、Parameters等）
        """
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key == constant.IMAGE_ID:
                    # 找到 ImageId 字段，提取其值
                    self._extract_image_values(value, image_ids, context)
                else:
                    # 递归搜索其他字段
                    self._search_image_ids(value, image_ids, context)
        elif isinstance(obj, list):
            for item in obj:
                self._search_image_ids(item, image_ids, context)

    @staticmethod
    def _extract_image_values(value, image_ids, context):
        """提取镜像值，支持ROS函数"""
        if isinstance(value, str):
            # 直接的字符串值
            image_ids.add(value)
        elif isinstance(value, dict):
            # 检查是否是ROS函数
            artifact_registry = ArtifactRegistry()
            ros_function_handled = False

            for ros_function_name, function_args in value.items():
                handler = artifact_registry.get_handler(ros_function_name)
                if handler:
                    handler.extract_image_ids(function_args, image_ids, context)
                    ros_function_handled = True
                    break

            # 如果不是支持的ROS函数，递归处理字典的值
            if not ros_function_handled:
                for v in value.values():
                    CheckProcessor._extract_image_values(v, image_ids, context)
        elif isinstance(value, list):
            # 处理列表类型的值
            for item in value:
                CheckProcessor._extract_image_values(item, image_ids, context)

    def run_checks(self):
        for check_func in self.checks:
            if not check_func():
                return False
        return True

    def print_errors(self):
        if self.errors:
            error_messages = []
            for error in self.errors:
                error_messages.append(error)
            raise ValueError(
                f"YAML file parameters are incorrect. Please modify and try again.\nThe error messages: {', '.join(error_messages)}")
        else:
            user_logger.error("Config is valid.")

    @log_monitor(BUILD_SERVICE, "")
    def processor(self):
        if self.run_checks():
            user_logger.info("Validation check: The config.yaml is correct!")
        else:
            self.print_errors()
