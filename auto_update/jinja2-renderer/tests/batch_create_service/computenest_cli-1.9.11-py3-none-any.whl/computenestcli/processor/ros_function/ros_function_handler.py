from abc import ABC, abstractmethod


class ROSFunctionHandler(ABC):
    """ROS函数处理器抽象基类"""

    @abstractmethod
    def can_handle(self, ros_function_name):
        """判断是否能处理指定的ROS函数"""
        pass

    @abstractmethod
    def extract_image_ids(self, function_args, image_ids, context):
        """从ROS函数中提取镜像ID"""
        pass


class FindInMapHandler(ROSFunctionHandler):
    """处理 Fn::FindInMap 函数 - 用于部署物关联"""

    def can_handle(self, ros_function_name):
        return ros_function_name == 'Fn::FindInMap'

    def extract_image_ids(self, function_args, image_ids, context):
        """
        处理 Fn::FindInMap 函数
        格式: [MapName, TopLevelKey, SecondLevelKey]
        """
        if not isinstance(function_args, list) or len(function_args) != 3:
            return

        map_name, top_level_key, second_level_key = function_args
        mappings = context.get('mappings')

        if not mappings or map_name not in mappings:
            return

        try:
            # 处理 SecondLevelKey 可能是 Ref 的情况
            if isinstance(second_level_key, dict) and 'Ref' in second_level_key:
                # 无法确定 Ref 的具体值，提取该层级的所有镜像ID
                if top_level_key in mappings[map_name]:
                    for artifact_id in mappings[map_name][top_level_key].values():
                        if isinstance(artifact_id, str):
                            image_ids.add(artifact_id)
            else:
                # 直接查找映射值
                if (top_level_key in mappings[map_name] and
                        second_level_key in mappings[map_name][top_level_key]):

                    artifact_id = mappings[map_name][top_level_key][second_level_key]
                    if isinstance(artifact_id, str):
                        image_ids.add(artifact_id)
        except (KeyError, TypeError):
            # 映射查找失败时静默忽略
            pass


class ConditionalHandler(ROSFunctionHandler):
    """处理 Fn::If 函数 - 用于条件部署物选择"""

    def can_handle(self, ros_function_name):
        return ros_function_name == 'Fn::If'

    def extract_image_ids(self, function_args, image_ids, context):
        """
        处理 Fn::If 函数
        格式: [condition, value_if_true, value_if_false]
        """
        if not isinstance(function_args, list) or len(function_args) != 3:
            return

        # 提取条件为真和为假时的值，因为无法确定运行时条件
        _, true_value, false_value = function_args

        # 需要导入 CheckProcessor 来递归处理
        from computenestcli.check_processor import CheckProcessor
        CheckProcessor._extract_image_values(true_value, image_ids, context)
        CheckProcessor._extract_image_values(false_value, image_ids, context)


class ArtifactRegistry:
    """部署物处理器注册表"""

    def __init__(self):
        self.handlers = []
        self._register_handlers()

    def _register_handlers(self):
        """注册部署物相关的处理器"""
        self.register_handler(FindInMapHandler())
        self.register_handler(ConditionalHandler())

    def register_handler(self, handler):
        """注册新的处理器"""
        self.handlers.append(handler)

    def get_handler(self, ros_function_name):
        """获取能处理指定ROS函数的处理器"""
        for handler in self.handlers:
            if handler.can_handle(ros_function_name):
                return handler
        return None
