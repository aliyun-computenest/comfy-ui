import sys

import yaml
from click import ClickException
import traceback
from computenestcli.base_log import get_developer_logger, get_logger
from computenestcli.common.logging_type import LoggingType
from computenestcli.exception.cli_common_exception import CliCommonException

developer_logger = get_developer_logger()
root = get_logger(LoggingType.ROOT.value)


class GlobalExceptionHandler:
    def __init__(self):
        pass

    def exception_handler(self, exctype, value, exp_traceback):
        traceback_info = ''.join(traceback.format_tb(exp_traceback))
        if issubclass(exctype, ZeroDivisionError):
            self.handle_zero_division_error(value, traceback_info)
        elif issubclass(exctype, FileNotFoundError):
            self.handle_file_not_found_error(value, traceback_info)
        elif issubclass(exctype, yaml.YAMLError):
            self.handle_yaml_error(value, traceback_info)
        elif issubclass(exctype, KeyError):
            self.handle_key_error(value, traceback_info)
        elif issubclass(exctype, CliCommonException):
            self.handle_cli_common_exception(value, traceback_info)
        elif issubclass(exctype, ClickException):
            self.handle_click_exception(value, traceback_info)
        else:
            self.handle_generic_error(exctype, value, traceback_info)

    def handle_click_exception(self, value, traceback_info):
        developer_logger.error(f"{value}, traceback={traceback_info}", exc_info=1)

    def handle_cli_common_exception(self, value, traceback_info):
        original = getattr(value, 'original_exception', None)
        if original:
            # 获取原始异常的完整堆栈信息
            original_traceback = ''.join(traceback.format_exception(
                type(original), original, original.__traceback__))

            # 打印原始异常的详细信息
            developer_logger.error(f"Original error: {type(original).__name__}: {original}")
            developer_logger.error(f"Original traceback:\n{original_traceback}")

            # 打印包装异常的信息
            developer_logger.error(f"Wrapped exception: {value}, traceback={traceback_info}")
        else:
            # 没有原始异常，只打印当前异常
            developer_logger.error(f"{value}, traceback={traceback_info}", exc_info=1)

    def handle_zero_division_error(self, value, traceback_info):
        developer_logger.error(f"Zero Division Error: {value}, traceback={traceback_info}", exc_info=1)

    def handle_file_not_found_error(self, value, traceback_info):
        developer_logger.error(f"File Not Found Error: {value}, traceback={traceback_info}", exc_info=1)

    def handle_yaml_error(self, value, traceback_info):
        developer_logger.error(f"YAML Parsing Error {value}, traceback={traceback_info}", exc_info=1)

    def handle_key_error(self, value, traceback_info):
        developer_logger.error(f"Dict Key Error {value}, traceback={traceback_info}", exc_info=1)

    def handle_generic_error(self, exctype, value, traceback_info):
        developer_logger.error(f"Inner Exception {value}, traceback={traceback_info}", exc_info=1)


# 设置全局异常处理钩子
exception_handler = GlobalExceptionHandler()
sys.excepthook = exception_handler.exception_handler
