import functools
import logging
import logging.config
import threading
import time
import traceback

import yaml
import sys

if sys.version_info >= (3, 10):
    from importlib import resources
else:
    import importlib_resources as resources

from computenestcli.exception.cli_common_exception import CliCommonException
from computenestcli.common.logging_constant import PROCESS_LOGGER, DEFAULT_PROGRESS, DEVELOPER_INFO_LOG_HANDLER_NAME, \
    LOGGING_CLOSURE_NAME
from computenestcli.common.logging_type import LoggingType

logging_initialized = False
global_config = None


class UTCFormatter(logging.Formatter):
    converter = time.gmtime


class InfoWarningFilter(logging.Filter):
    def filter(self, record):
        return record.levelno == logging.INFO or record.levelno == logging.WARNING


def load_process_config():
    global global_config
    if global_config is None:
        logger_path = resources.files(__package__).joinpath(PROCESS_LOGGER)
        with logger_path.open() as f:
            global_config = yaml.safe_load(f.read())
    return global_config


def setup_logging(config_file='log.conf'):
    """Set up logging configuration from a configuration file."""
    global logging_initialized
    if not logging_initialized:
        # 获取配置文件的路径
        with resources.path(__package__, config_file) as config_path:
            logging.config.fileConfig(config_path)
            # 设置所有格式化器的转换器为 time.gmtime（UTC时间）
            for logger_name in logging.root.manager.loggerDict:
                logger = logging.getLogger(logger_name)
                for handler in logger.handlers:
                    formatter = handler.formatter
                    if isinstance(formatter, logging.Formatter):
                        formatter.converter = time.gmtime

            # 处理 root logger 的处理器
            for handler in logging.root.handlers:
                formatter = handler.formatter
                if isinstance(formatter, logging.Formatter):
                    formatter.converter = time.gmtime
        logging_initialized = True


def get_logger(name):
    """Get a logger with the specified name."""
    return logging.getLogger(name)


def get_developer_logger():
    setup_logging()
    developer_logger = get_logger(LoggingType.DEVELOPER.value)
    for handler in developer_logger.handlers:
        if handler.get_name() == DEVELOPER_INFO_LOG_HANDLER_NAME:
            handler.addFilter(InfoWarningFilter())
    return developer_logger


def get_user_logger(service_name):
    """
    获取用户 Logger，并注入 service_name 作为上下文信息。

    :param service_name: 服务名称，必须提供。
    :return: LoggerAdapter 对象，带有 service_name 信息。
    """
    if not service_name:
        raise CliCommonException("Service name is required.")

    setup_logging()
    base_logger = get_logger(LoggingType.USER.value)

    # 确保使用的格式化器包含 service_name
    for handler in base_logger.handlers:
        formatter = handler.formatter
        if isinstance(formatter, logging.Formatter):
            if '%(service_name)s' not in formatter._fmt:
                # 修改格式以包含 service_name
                formatter._fmt = f'[%(asctime)s][%(levelname)s][%(service_name)s] %(message)s'

    # 使用 LoggerAdapter 注入 service_name
    return logging.LoggerAdapter(base_logger, {'service_name': service_name})


def __get_inner_logger():
    setup_logging()
    return get_logger(LoggingType.INNER.value)


"""
Decorator to log the execution of a process.

:param service_name: Represents the execution of a CLI command, e.g., `import`.
:param process_name: A major step in the execution, e.g., `BuildArtifacts`.
:param task_name: A minor step/component of the process, e.g., AcrImageBuild.
:param periodic_logging: A boolean flag indicating if periodic logs should be printed 
                         for long-running tasks.
:param dynamic_logging: A boolean flag indicating if dynamic logging should be enabled.
                        If True, passes a logging closure to the decorated function.

用于记录进程执行的装饰器。
:param service_name: 表示CLI命令的执行，例如 import。
:param process_name: 执行过程中的主要步骤，例如 BuildArtifacts。
:param task_name: 进程中的次要步骤或组件，例如 AcrImageBuild。
:param periodic_logging: 一个布尔标志，指示是否应为长时间运行的任务打印周期性日志。
:param dynamic_logging: 一个布尔标志，指示是否应启用动态日志记录。
如果为 True，则将日志记录闭包传递给装饰的函数。
"""


def log_monitor(service_name, process_name, task_name=None, periodic_logging=False, dynamic_logging=False,
                periodic_logging_interval=30):
    def get_step_info(service_name, step_name):
        # 如果process_name为None或空字符串，返回None
        if not step_name:
            return None

        config = load_process_config()
        process_steps = config.get(service_name, {})
        if not process_steps:
            raise ValueError(f"Service {service_name} not found.")

        step_order = process_steps.get(step_name)
        if step_order is None:
            return DEFAULT_PROGRESS

        total_steps = max(process_steps.values())
        return f"{step_order}/{total_steps}"

    # 获取进度信息
    progress = get_step_info(service_name, process_name)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger = __get_inner_logger()

            # 基本的extra信息
            extra = {'service_name': service_name}

            # 只有当progress不为None时才添加到extra中
            if progress is not None:
                extra['progress'] = progress

            # 创建一个自定义的日志处理函数，根据extra中是否有progress来决定日志格式
            def custom_log(level, message):
                # 获取所有处理器
                handlers = logger.handlers

                for handler in handlers:
                    if not hasattr(handler, 'formatter'):
                        continue

                    formatter = handler.formatter
                    record = logging.LogRecord(
                        name=logger.name,
                        level=level,
                        pathname="",
                        lineno=0,
                        msg=message,
                        args=(),
                        exc_info=None
                    )

                    # 添加extra中的信息到record
                    for key, value in extra.items():
                        setattr(record, key, value)

                    # 如果没有progress，但格式中需要progress，添加一个空的
                    if 'progress' not in extra and '%(progress)s' in formatter._fmt:
                        record.progress = ""

                    # 格式化并发送日志
                    if logger.isEnabledFor(level):
                        try:
                            formatted_message = formatter.format(record)
                            # 移除空的progress括号 [  ]
                            if 'progress' not in extra:
                                formatted_message = formatted_message.replace('[]', '')
                            handler.stream.write(formatted_message + handler.terminator)
                            handler.stream.flush()
                        except Exception:
                            # 如果格式化失败，回退到简单日志
                            handler.stream.write(f"[{record.levelname}] {message}" + handler.terminator)
                            handler.stream.flush()

            def log_message(message, error=False):
                # 拆分消息为多行，过滤掉空行
                lines = [line for line in message.split('\n') if line.strip()]

                if error:
                    # 错误日志：记录第一行 + 最后一行
                    if len(lines) >= 2:
                        # 第一行：异常类型（如 Traceback...）
                        custom_log(logging.ERROR, f"{lines[0]}")
                        # 最后一行：核心错误信息（如 ValueError: ...）
                        custom_log(logging.ERROR, f"Error: {lines[-1]}")
                    else:
                        for line in lines or [message]:
                            custom_log(logging.ERROR, line)
                else:
                    # 普通日志：逐行完整记录
                    for line in lines or [message]:  # 处理空列表情况
                        custom_log(logging.INFO, line)

            # 可供调用的闭包，用于被装饰的对象动态传入日志
            def dynamic_logging_message(message):
                custom_log(logging.INFO, message)

            if dynamic_logging:
                kwargs[LOGGING_CLOSURE_NAME] = dynamic_logging_message

            stop_thread = None
            logging_thread = None

            def periodic_logging_task():
                if stop_thread:
                    while not stop_thread.is_set():
                        # 使用 wait 代替 sleep，使其可以被提前中断
                        if stop_thread.wait(periodic_logging_interval):
                            break
                        if task_name:
                            custom_log(logging.INFO, f"{task_name} is processing...")
                        elif process_name:  # 确保process_name不为空
                            custom_log(logging.INFO, f"{process_name} is processing...")


            try:
                if periodic_logging:
                    stop_thread = threading.Event()
                    logging_thread = threading.Thread(target=periodic_logging_task)
                    logging_thread.start()
                else:
                    stop_thread = None
                    logging_thread = None

                # 日志开始
                if task_name and process_name:
                    log_message(f"{process_name}-{task_name} Start!")
                elif process_name:
                    log_message(f"{process_name} Start!")

                custom_log(logging.INFO, "Processing...")
                result = func(*args, **kwargs)
                # 至少停留1s再将日志线程优雅关闭
                time.sleep(1)
                if logging_thread is not None:
                    stop_thread.set()
                    logging_thread.join()

                # 日志成功
                if task_name and process_name:
                    log_message(f"{process_name}-{task_name} Success!")
                elif process_name:
                    log_message(f"{process_name} Success!")


                return result
            except Exception as e:
                if logging_thread is not None:
                    stop_thread.set()
                    logging_thread.join()

                # 检查异常是否已经被另一个 log_monitor 处理过
                if hasattr(e, '_logged_by_monitor'):
                    # 这个异常已经被记录过，简单记录一下外层上下文
                    if task_name and process_name:
                        custom_log(logging.ERROR, f"{process_name}-{task_name} failed due to an error in inner process")
                    elif process_name:
                        custom_log(logging.ERROR, f"{process_name} failed due to an error in inner process")
                    else:
                        custom_log(logging.ERROR, "Process failed due to an error in inner process")
                    # 直接重新抛出异常
                    raise

                # 异常未被处理过，记录完整的异常信息
                error_trace = traceback.format_exc()
                exception_type = type(e).__name__
                exception_module = type(e).__module__
                full_exception_type = f"{exception_module}.{exception_type}" if exception_module != "builtins" else exception_type

                if task_name and process_name:
                    log_message(
                        f"Error occurred in {process_name}-{task_name}! Exception type: {full_exception_type}\n{error_trace}",
                        error=True)
                elif process_name:
                    log_message(f"Error occurred in {process_name}! Exception type: {full_exception_type}\n{error_trace}",
                                error=True)
                else:
                    log_message(f"Error occurred in {service_name}! Exception type: {full_exception_type}\n{error_trace}",
                                error=True)

                # 创建新的异常并标记它已被处理
                cli_exception = CliCommonException(
                    f"[{service_name}] CLI has stopped running due to an error (caused by {e})",
                    original_exception=e
                )
                setattr(cli_exception, '_logged_by_monitor', True)

                raise cli_exception from e

        return wrapper

    return decorator
